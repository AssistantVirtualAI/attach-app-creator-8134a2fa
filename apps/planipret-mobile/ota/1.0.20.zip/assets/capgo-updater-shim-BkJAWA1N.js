const a=null,t={CapacitorUpdater:null};export{a as CapacitorUpdater,t as default};

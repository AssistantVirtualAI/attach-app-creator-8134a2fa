import{r as o}from"./vendor-react-ebUkLV9r.js";function a(){const[i,r]=o.useState({top:0,bottom:0,left:0,right:0});return o.useEffect(()=>{const e=document.createElement("div");e.style.cssText=`
      position: fixed;
      top: env(safe-area-inset-top);
      left: env(safe-area-inset-left);
      right: env(safe-area-inset-right);
      bottom: env(safe-area-inset-bottom);
      pointer-events: none;
      visibility: hidden;
    `,document.body.appendChild(e);const n=()=>{const t=e.getBoundingClientRect();r({top:Math.round(t.top),bottom:Math.round(window.innerHeight-t.bottom),left:Math.round(t.left),right:Math.round(window.innerWidth-t.right)})};return n(),window.addEventListener("resize",n),()=>{window.removeEventListener("resize",n),e.remove()}},[]),i}export{a as u};

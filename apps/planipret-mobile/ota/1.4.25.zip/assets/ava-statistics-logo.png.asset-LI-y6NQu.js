const s="https://avastatistic.ca/__l5e/assets-v1/42b6ec50-be7d-4939-912c-622a3f1880c3/ava-statistics-logo.png",a={url:s};export{a};

function n(e,r){var a;try{const t=(a=localStorage.getItem("mplanipret-lang"))!=null?a:localStorage.getItem("ava-language");if(t==="en")return r;if(t==="fr")return e}catch(t){}return e}export{n as t};
